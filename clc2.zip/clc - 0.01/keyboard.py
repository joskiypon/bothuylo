from cfg import *

button = ReplyKeyboardMarkup(keyboard=[
    [KeyboardButton(text='💵 Заработать')],
    [KeyboardButton(text='👤 Профиль')],
],
                        resize_keyboard=True)

def get_inline_kb():
    inline_kb_list = [
        [InlineKeyboardButton(text="Вывести средства", callback_data='money')]
    ]
    return InlineKeyboardMarkup(inline_keyboard=inline_kb_list)

def payment_keyboard() -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton(text="Оплатить 222 ⭐️", pay=True)]
    ]
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    return kb