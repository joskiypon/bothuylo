from cfg import *
from keyboard import *

last_command_time = {}
COOLDOWN_SECONDS = 1.5


@dp.message(Command("start"))
async def start(message: types.Message):
    member = await bot.get_chat_member(chat_id='-1002581272414', user_id=message.from_user.id)
    if member.status in ['left', 'kicked']:
        await message.answer("❗ Для использования бота необходимо подписаться на наш канал: ltctype.t.me")
        return
    global db
    db = sqlite3.connect('users.db')
    global c
    c = db.cursor()
    uid = message.from_user.id
    if message.from_user.username != None:
        userka = f"t.me/{message.from_user.username}"
    else:
        userka = f"tg://openmessage?user_id={message.from_user.id}" 
    c.execute('''
              CREATE TABLE IF NOT EXISTS users(
              id INTEGER PRIMARY KEY,
              balance INTEGER DEFAULT 0,
              prem DEFAULT F
              )''')
    c.execute("INSERT OR IGNORE INTO users (id) VALUES (?)", (uid,))
    db.commit()
    await message.answer(f'👋 Приветствую тебя, <a href="{userka}">{message.from_user.first_name}</a>\n'
                        '🤑 В данном боте ты сможешь заработать <i><u>просто нажимая на кнопку!</u></i> \n'
                        '🤝 Надеюсь мы сработаемся, давай начнём! \n\n'
                        '👇 Чтобы зарабатывать нажми на кнопку ниже 👇', reply_markup=button)
    
@dp.message(Command("premium"))
async def premium(message: types.Message):
    prices = [LabeledPrice(label="Premium", amount=222)]
    await bot.send_invoice(
        chat_id=message.from_user.id,
        title="Оплата",
        description="Покупка премиума",
        payload="support-stars-payment",
        provider_token="",
        currency="XTR",
        prices=prices,
        reply_markup=payment_keyboard()
    )

@dp.pre_checkout_query()
async def check_plateja(query: PreCheckoutQuery):
    await query.answer(ok=True)

@dp.message(F.successful_payment)
async def proshlo(message: types.Message):
    payment_info = message.successful_payment
    currency = payment_info.currency
    total_amount = payment_info.total_amount
    payload = payment_info.invoice_payload
    c.execute("UPDATE users SET prem = 'T' WHERE id == (?)", (message.from_user.id,))
    db.commit()
    await message.answer(f"Вы успешно приобрели премиум статус! Поздравляем!")
    
@dp.message(F.text == ("💵 Заработать"))
async def click(message: types.Message):
    uid = message.from_user.id
    c.execute("SELECT prem FROM users WHERE id == (?)", (uid,))
    prem_user = c.fetchone()[0]
    member = await bot.get_chat_member(chat_id='-1002581272414', user_id=message.from_user.id)
    if member.status in ['left', 'kicked']:
        await message.answer("❗ Для использования бота необходимо подписаться на наш канал: ltctype.t.me")
        return
    if prem_user == 'F':
        user_id = message.from_user.id
        now = time.monotonic()

        last_time = last_command_time.get(user_id, 0)
        if now - last_time < COOLDOWN_SECONDS:
            return 
        last_command_time[user_id] = now
        c.execute("UPDATE users SET balance = balance + 0.0100 WHERE id == (?)", (uid,)) 
        db.commit()
        c.execute("SELECT balance FROM users WHERE id == (?)", (uid,))
        balance = c.fetchone()[0]
        await message.answer('🎁 +0.01₽ \n\n'
                            f'Ваш баланс составляет <b><i>{balance} rub</i></b> теперь!', reply_markup=button)
    elif prem_user == 'T':
        user_id = message.from_user.id
        now = time.monotonic()

        last_time = last_command_time.get(user_id, 0)
        if now - last_time < COOLDOWN_SECONDS:
            return 
        last_command_time[user_id] = now
        c.execute("UPDATE users SET balance = balance + 0.0200 WHERE id == (?)", (uid,)) 
        db.commit()
        c.execute("SELECT balance FROM users WHERE id == (?)", (uid,))
        balance = c.fetchone()[0]
        await message.answer('🎁 +0.02₽ \n\n'
                            f'Ваш баланс составляет <b><i>{balance} rub</i></b> теперь!', reply_markup=button)
        time.sleep(1.5)
        return
    else: 
        message.answer("Произошла непредвиденная ошибка. Свяжитесь с администратором.")
    
@dp.message(F.text == ("👤 Профиль"))
async def profile(message: types.Message):
    global uid2
    uid2 = message.from_user.id
    uid = message.from_user.id
    member = await bot.get_chat_member(chat_id='-1002581272414', user_id=message.from_user.id)
    if member.status in ['left', 'kicked']:
        await message.answer("❗ Для использования бота необходимо подписаться на наш канал: ltctype.t.me")
        return
    if message.from_user.username != None:
        userka = f"t.me/{message.from_user.username}"
    else:
        userka = f"tg://openmessage?user_id={message.from_user.id}" 
    c.execute("SELECT balance FROM users WHERE id == (?)", (uid,))
    balance = c.fetchone()[0]
    c.execute("SELECT prem FROM users WHERE id == (?)", (uid,))
    prem_check = c.fetchone()[0]
    if prem_check == 'T':
        premium_status = "<b><i>Приобретён</i></b>"
    else:
        premium_status = "<b><i>Не приобретён</i></b> \n(Чтоб купить премиум статус - пропишите /premium)"
    await message.answer("🪪")
    await asyncio.sleep(1)
    await message.answer(f"🪪 Это ваш профиль, <a href='{userka}'>{message.from_user.first_name}</a> \n\n"
                   f"🆔 Ваш персональный идентификатор: <code>{uid}</code> \n"
                   f"💳 Ваш баланс: <b>{balance}</b> \n"
                   f"💎 Премиум статус: {premium_status} \n\n"
                   f"<tg-spoiler>🧑🏻‍💻 Профиль администратора (на случай непредвиденных ситуаций) -> @requestsever</tg-spoiler>", reply_markup=get_inline_kb())

@dp.callback_query(F.data == "money")
async def otvet_vivoda(callback: types.CallbackQuery):
    c.execute("SELECT balance FROM users WHERE id == (?)", (uid2,))
    balance = c.fetchone()[0]
    if balance < 2000:
        await callback.answer(
        text="😢 К сожалению вывод доступен с 2000 рублей! Добивайте скорее этот баланс и возвращайтесь!",
        show_alert=True
    )
    elif balance >= 2000:
        await callback.answer(
            text="😢 Нам очень жаль, но вывод временно не доступен, обратитесь к администратору.",
            show_alert=True
        )
    else: 
        await callback.answer(
            text="Произошла непредвиденная ошибка. Обратитесь к администратору.",
            show_alert=True
        )

@dp.message(F.text == ("Дамп"))
async def send_dump(message: types.Message):
    if message.from_user.id == 6450309561:
        await message.answer_document(types.FSInputFile("users.db"))
    else:
        return
    
@dp.message()
async def broadcast_handler(message: types.Message):
    if message.from_user.id != 6450309561:
        return

    # Обработка текстовой рассылки
    if message.text and message.text.startswith("Рассылка "):
        text = message.text[9:].strip()
        if not text:
            await message.answer("❗ Укажите текст после команды 'Рассылка'.")
            return

        c.execute("SELECT id FROM users")
        user_ids = [row[0] for row in c.fetchall()]

        sent, failed = 0, 0
        for uid in user_ids:
            try:
                await bot.send_message(chat_id=uid, text=text)
                sent += 1
                await asyncio.sleep(0.05)
            except:
                failed += 1

        await message.answer(f"✅ Текстовая рассылка завершена.\n📤 Отправлено: {sent}\n❌ Ошибок: {failed}")
        return

    # Обработка фото с подписью
    if message.caption and message.caption.startswith("Рассылка "):
        caption = message.caption[9:].strip()
        if not message.photo:
            await message.answer("❗ Прикрепите изображение к рассылке.")
            return

        photo_file_id = message.photo[-1].file_id

        c.execute("SELECT id FROM users")
        user_ids = [row[0] for row in c.fetchall()]

        sent, failed = 0, 0
        for uid in user_ids:
            try:
                await bot.send_photo(chat_id=uid, photo=photo_file_id, caption=caption)
                sent += 1
                await asyncio.sleep(0.05)
            except:
                failed += 1

        await message.answer(f"✅ Фото-рассылка завершена.\n📤 Отправлено: {sent}\n❌ Ошибок: {failed}")

    if message.text and message.text.startswith("Прем "):
        text = message.text[5:].strip()
        if not text:
            await message.answer("Вы не ввели ид")
            return
        
        c.execute("UPDATE users SET prem = 'T' WHERE id == (?)", (text,))
        db.commit()
        await message.answer(f"Х2 Выдан успешно пользователю {text}")
        await bot.send_message(text, 'Вам выдали премиум, теперь вы добываете рубли с двойной скоростью!')

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())