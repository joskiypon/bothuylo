import aiogram
import asyncio
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.filters.command import Command
from aiogram import F, Bot, Dispatcher, types
from aiogram.types import InputFile
from aiogram.types import LabeledPrice
from aiogram.enums import Currency
from aiogram.types import PreCheckoutQuery
import sqlite3
import time


bot = Bot(token='7293802824:AAHYpBTr7dtLwFUqdCOPSJ2LJDu5Th_nYlM', parse_mode='html', disable_web_page_preview=True)
dp = Dispatcher()